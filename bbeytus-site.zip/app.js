const express = require("express");
const app = express();
const path = require("path");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const sequelize = require("./data/db");
const Category = require("./models/category");
const Menu = require("./models/menu");

app.set("view engine", "ejs");

app.use("/static", express.static(path.join(__dirname, "assets")));
app.use("/static2", express.static(path.join(__dirname, "assets2")));
app.use("/libs", express.static(path.join(__dirname, "node_modules")));

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser()); 
app.use(
  session({
    secret: "hello",
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 30,
    },
  })
);

const userRoutes = require("./routes/user");
const adminRoutes = require("./routes/admin");
const authRoutes = require("./routes/auth");
app.use("/admin", adminRoutes);
app.use("/account", authRoutes);
app.use(userRoutes);

const dummyData = require("./data/test");

(async () => {
  await sequelize.sync({ alter: true });
  await dummyData();
})();

Category.hasMany(Menu, {
  foreignKey: {
    name: "categoryId",
    allowNull: false,
    defaultValue: 1,
  },
});
Menu.belongsTo(Category);

app.listen(3000, () => {
  console.log("localhost 3000");
});