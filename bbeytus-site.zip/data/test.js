const Soz = require("../models/soz");
const Slider = require("../models/slider");
const Hakkimizda = require("../models/hakkimizda");
const Galeri = require("../models/galeri")
const Ekip = require("../models/ekip")
const Form = require("../models/form")
const User = require("../models/user");
const Category = require("../models/category");
const Menu = require("../models/menu");

async function populate() {
  const sozcount = await Soz.count();
  if (sozcount == 0) {
    await Soz.create({
      yazi: "Günün sonunda kiminle beytuşa geliyorsan doğru kişi odur.",
    });
  }
  const slidercount = await Slider.count();
  if (slidercount == 0) {
    await Slider.create({
      resim: "beytusslider3.jpg",
    });
  }
  const hakkimizdacount = await Hakkimizda.count();
  if (hakkimizdacount == 0) {
    await Hakkimizda.create({
      resim: "beytusabout3.jpg",
      resim2: "beytusabout5.jpg",
      aciklama: "hakkimizda deneme"
    });
  }
  const galericount = await Galeri.count();
  if (galericount == 0) {
    await Galeri.create({
      resim: "beytuschef2.jpg",
    });
  }
  const ekipcount = await Ekip.count();
  if (ekipcount == 0) {
    await Ekip.create({
      isim:"Mehmet Yılmaz",
      aciklama:"Beytuş Şef",
      resim: "beytuschef2.jpg",
    });
  }
  const formcount = await Form.count();
  if (formcount == 0) {
    await Form.create({
      isim:"Mehmet Yılmaz",
      mail:"ensar@gmail.com",
      mesaj: "deneme mesaj",
    });
  }
  const usercount = await User.count();
  if (usercount == 0) {
    await User.create({
      fullName:"admin",
      password:"admin",
    });
  }
  const menucount = await Menu.count();
  if (menucount == 0) {
    await Menu.create({
      resim:"beytusabout3.jpg",
      isim:"Hamburger",
      fiyat:"100",
      aciklama:"sala",
    });
  }
  const categorycount = await Category.count();
  if (categorycount == 0) {
    await Category.create({
      name: "Burgerler",
    });
  }
}

module.exports = populate;