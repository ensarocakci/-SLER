const config = {
    db: {
      host: "localhost",
      user: "root",
      password: "",
      database: "beytus",
    },
  };
  
  module.exports = config;
  