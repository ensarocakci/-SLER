const express = require("express");
const router = express.Router();
const Slider = require("../models/slider");
const Hakkimizda = require("../models/hakkimizda");
const Ekip = require("../models/ekip");
const Menu = require("../models/menu");
const Category = require("../models/category");
const Soz = require("../models/soz");
const Galeri = require("../models/galeri");
const Form = require("../models/form");


router.post("/iletisim", async function (req, res) {
    const isim = req.body.isim;
    const mail = req.body.mail;
    const mesaj = req.body.mesaj;
    try {
        await Form.create({
            isim:isim,
            mail:mail,
            mesaj:mesaj,
        });
    } catch (error) {
    }
    return res.redirect("iletisim?action=form&isim=" + isim + "#1");
});
router.get("/iletisim", async function (req, res) {
    try {
        res.render("users/iletisim", {
            isim: req.query.isim,
            action: req.query.action,
        });
    } catch (err) {
    }
});
router.get("/galeri", async function (req, res) {
    try {
        const galeri = await Galeri.findAll();
        res.render("users/galeri", {
            galeri:galeri,
        });
    } catch (err) {
    }
});
router.get("/menu",async function (req, res) {
    try {
        const menu = await Menu.findAll();
        const category = await Category.findAll();
        res.render("users/menu", {
            menu: menu,
            category:category,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/hakkimizda",async function (req, res) {
    try {
        const hakkimizda = await Hakkimizda.findAll();
        res.render("users/hakkimizda", {
            hakkimizda: hakkimizda,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/", async function (req, res) {
    try {
        const hakkimizda = await Hakkimizda.findAll();
        const slider = await Slider.findAll();
        const ekip = await Ekip.findAll();
        const soz = await Soz.findAll();
        const galeri = await Galeri.findAll();
        res.render("users/index", {
            slider: slider,
            ekip: ekip,
            galeri:galeri,
            soz:soz,
            hakkimizda: hakkimizda,
        });
    } catch (err) {
        console.log(err);
    }
});

module.exports = router;