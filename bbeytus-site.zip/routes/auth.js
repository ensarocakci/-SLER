const express = require("express");
const router = express.Router();
const User = require("../models/user");

//anasayfa
router.get("/login", function (req, res) {
  res.render("admin/login");
});

router.post("/login", async function (req, res) {
  const kadi = req.body.kadi;
  const parola = req.body.parola;

  try {
    const user = await User.findOne({
      where: {
        fullName: kadi,
      },
    });

    //kullanıcı adı kontrolü
    if (!user) {
      return res.render("admin/login");
    }

    //parola kontrolü
    if (parola == user.password) {
      //login olduk
      req.session.isAuth = true;
      return res.redirect("/admin");
    }
    return res.render("admin/login");
  } catch (err) {
    console.log(err);
  }
});

module.exports = router;
