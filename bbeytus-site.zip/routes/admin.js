const express = require("express");
const router = express.Router();
const Slider = require("../models/slider");
const Hakkimizda = require("../models/hakkimizda");
const Soz = require("../models/soz");
const Ekip = require("../models/ekip");
const Galeri = require("../models/galeri");
const Form = require("../models/form");
const Category = require("../models/category");
const Menu = require("../models/menu");
const imageUpload = require("../helpers/image-upload");
const isAuth = require("../middlewares/auth");
const fs = require("fs");

//kategori SİLME İŞLEMİ
router.post("/category", isAuth, async function (req, res) {
    const categoryid = req.body.categoryid;

    try {
        await Category.destroy({
            where: {
                id: categoryid,
            },
        });
        return res.redirect("/admin/category");
    } catch (err) {
        console.log(err);
    }
});

//Kategori  DÜZENLEME SAYFASI
router.get("/category/:categoryid", isAuth, async function (req, res) {
    const categoryid = req.params.categoryid;
    try {
        const category = await Category.findByPk(categoryid);
        if (category) {
            return res.render("admin/edit/category-edit", {
                category: category,
            });
        }
        res.redirect("/admin/category");
    } catch (err) {
        console.log(err);
    }
});
//Kategori DÜZENLEME İŞLEMİ
router.post(
    "/category/:categoryid",
    isAuth, async function (req, res) {
        const categoryid = req.params.categoryid;
        const isim = req.body.isim;
        try {
            await Category.update(
                {
                    name: isim,
                },
                {
                    where: {
                        id: categoryid,
                    },
                }
            );
            return res.redirect("/admin/category");       
        } catch (err) {
            console.log(err);
        }
    }
);

//Kategori EKLEME SAYFASI
router.get("/category-create", function (req, res) {
    res.render("admin/edit/category-create");
});
//Kategori EKLEME İŞLEMİ
router.post(
    "/category-create",
    isAuth, async function (req, res) {
        const isim = req.body.isim;
        try {
            await Category.create({
                name: isim,
            });
            return res.redirect("/admin/category");
        } catch (err) {
            console.log(err);
        }
    }
);

//MENÜ SİLME İŞLEMİ
router.post("/menu", isAuth, async function (req, res) {
    const menuid = req.body.menuid;

    try {
        await Menu.destroy({
            where: {
                id: menuid,
            },
        });
        return res.redirect("/admin/menu");
    } catch (err) {
        console.log(err);
    }
});

//MENÜ EKLEME SAYFASI
router.get("/menu-create", isAuth, async function (req, res) {
    try {
      const category = await Category.findAll();
      return res.render("admin/edit/menu-create", {
        category: category,
      });
      return res.redirect("/admin/menu");
    } catch (err) {
      console.log(err);
    }
  });
//MENÜ EKLEME İŞLEMİ
  router.post(
    "/menu-create",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
      const resim = req.file.filename;
      const isim = req.body.isim;
      const aciklama = req.body.aciklama;
      const fiyat = req.body.fiyat;
      const kategori = req.body.kategori;
      try {
        await Menu.create({
          resim: resim,
          isim: isim,
          aciklama: aciklama,
          fiyat: fiyat,
          categoryId: kategori,
        });
        return res.redirect("/admin/menu");
      } catch (err) {
        console.log(err);
      }
    }
  );

//EKİP EKLEME SAYFASI
router.get("/ekip-create", function (req, res) {
    res.render("admin/edit/ekip-create");
});
//EKİP EKLEME İŞLEMİ
router.post(
    "/ekip-create",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const resim = req.file.filename;
        const isim = req.body.isim;
        const aciklama = req.body.aciklama;
        try {
            await Ekip.create({
                resim: resim,
                isim: isim,
                aciklama: aciklama,
            });
            return res.redirect("/admin/ekip");
        } catch (err) {
            console.log(err);
        }
    }
);

//MENÜ  DÜZENLEME SAYFASI
router.get("/menu/:menuid", isAuth, async function (req, res) {
    const menuid = req.params.menuid;
    try {
        const menu = await Menu.findByPk(menuid);
        const category = await Category.findAll();
        if (menu) {
            return res.render("admin/edit/menu-edit", {
                menu: menu,
                category: category,
            });
        }
        res.redirect("/admin/menu");
    } catch (err) {
        console.log(err);
    }
});
//MENÜ DÜZENLEME İŞLEMİ
router.post(
    "/menu/:menuid",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const menuid = req.params.menuid;
        const isim = req.body.isim;
        const fiyat = req.body.fiyat;
        const aciklama = req.body.aciklama;
        const kategori = req.body.kategori;
        let resim = req.body.resim;
        if (req.file) {
            resim = req.file.filename;

            fs.unlink("./assets/uploads/" + req.body.resim, (err) => { });
        }
        try {
            await Menu.update(
                {
                    resim:resim,
                    isim: isim,
                    fiyat: fiyat,
                    aciklama: aciklama,
                    categoryId:kategori,
                },
                {
                    where: {
                        id: menuid,
                    },
                }
            );
            return res.redirect("/admin/menu");       
        } catch (err) {
            console.log(err);
        }
    }
);

//SOZ DÜZENLEME SAYFASI
router.get("/soz/:sozid", isAuth, async function (req, res) {
    const sozid = req.params.sozid;
    try {
        const soz = await Soz.findByPk(sozid);

        if (soz) {
            return res.render("admin/edit/soz-edit", {
                soz: soz,
            });
        }
        res.redirect("/admin/soz");
    } catch (err) {
        console.log(err);
    }
});
//SOZ DÜZENLEME İŞLEMİ
router.post(
    "/soz/:sozid",
    isAuth, async function (req, res) {
        const sozid = req.params.sozid;
        const yazi = req.body.yazi;
        try {
            await Soz.update(
                {
                    yazi: yazi,
                },
                {
                    where: {
                        id: sozid,
                    },
                }
            );
            return res.redirect("/admin/soz");       
        } catch (err) {
            console.log(err);
        }
    }
);
//SLİDER DÜZENLEME SAYFASI
router.get("/slider/:sliderid", isAuth, async function (req, res) {
    const sliderid = req.params.sliderid;
    try {
        const slider = await Slider.findByPk(sliderid);

        if (slider) {
            return res.render("admin/edit/slider-edit", {
                slider: slider,
            });
        }
        res.redirect("/admin/slider");
    } catch (err) {
        console.log(err);
    }
});
//SLİDER DÜZENLEME İŞLEMİ
router.post(
    "/slider/:sliderid",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const sliderid = req.params.sliderid;
        let resim = req.body.resim;
        if (req.file) {
            resim = req.file.filename;

            fs.unlink("./assets/uploads/" + req.body.resim, (err) => { });
        }
        try {
            await Slider.update(
                {
                    resim: resim,
                },
                {
                    where: {
                        id: sliderid,
                    },
                }
            );
            return res.redirect("/admin/slider");       
        } catch (err) {
            console.log(err);
        }
    }
);
//HAKKIMIZDA DÜZENLEME SAYFASI
router.get("/hakkimizda/:hakkimizdaid", isAuth, async function (req, res) {
    const hakkimizdaid = req.params.hakkimizdaid;
    try {
        const hakkimizda = await Hakkimizda.findByPk(hakkimizdaid);

        if (hakkimizda) {
            return res.render("admin/edit/hakkimizda-edit", {
                hakkimizda: hakkimizda,
            });
        }
        res.redirect("/admin/hakkimizda");
    } catch (err) {
        console.log(err);
    }
});
//HAKKIMIZDA DÜZENLEME İŞLEMİ
router.post(
    "/hakkimizda/:hakkimizdaid",
    imageUpload.upload.fields([{ name: "resim", maxCount: 1 }, { name: "resim2", maxCount: 1 }]),
    isAuth, async function (req, res) {
      const hakkimizdaid = req.params.hakkimizdaid;
      const aciklama = req.body.aciklama;
      let resim = req.body.existingResim;
      let resim2 = req.body.existingResim2;
  
      if (req.files.resim) {
        resim = req.files.resim[0].filename;
      }
  
      if (req.files.resim2) {
        resim2 = req.files.resim2[0].filename;
      }
  
      try {
        // Update Hakkimizda model
        await Hakkimizda.update(
          {
            aciklama: aciklama,
            resim: resim,
            resim2: resim2,
          },
          {
            where: {
              id: hakkimizdaid,
            },
          }
        );
  
        // Delete existing files only if new files are uploaded
        if (req.files.resim) {
          const existingResim = req.body.existingResim;
          if (existingResim && existingResim !== resim) {
            const filePath = `./assets/uploads/${existingResim}`;
            if (fs.existsSync(filePath)) {
              fs.unlink(filePath, (err) => {
                if (err) console.error(err);
              });
            }
          }
        }
  
        if (req.files.resim2) {
          const existingResim2 = req.body.existingResim2;
          if (existingResim2 && existingResim2 !== resim2) {
            const filePath = `./assets/uploads/${existingResim2}`;
            if (fs.existsSync(filePath)) {
              fs.unlink(filePath, (err) => {
                if (err) console.error(err);
              });
            }
          }
        }
  
        res.redirect("/admin/hakkimizda");
      } catch (err) {
        console.log(err);
      }
    }
  );

//FORM SİLME İŞLEMİ
router.post("/form", isAuth, async function (req, res) {
    const formid = req.body.formid;

    try {
        await Form.destroy({
            where: {
                id: formid,
            },
        });
        return res.redirect("/admin/form");
    } catch (err) {
        console.log(err);
    }
});
//EKİP SİLME İŞLEMİ
router.post("/ekip", isAuth, async function (req, res) {
    const ekipid = req.body.ekipid;

    try {
        await Ekip.destroy({
            where: {
                id: ekipid,
            },
        });
        return res.redirect("/admin/ekip");
    } catch (err) {
        console.log(err);
    }
});
//EKİP DÜZENLEME SAYFASI
router.get("/ekip/:ekipid", isAuth, async function (req, res) {
    const ekipid = req.params.ekipid;
    try {
        const ekip = await Ekip.findByPk(ekipid);

        if (ekip) {
            return res.render("admin/edit/ekip-edit", {
                ekip: ekip,
            });
        }
        res.redirect("/admin/ekip");
    } catch (err) {
        console.log(err);
    }
});
//EKİP DÜZENLEME İŞLEMİ
router.post(
    "/ekip/:ekipid",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const ekipid = req.params.ekipid;
        const isim = req.body.isim;
        const aciklama = req.body.aciklama;
        let resim = req.body.resim;
        if (req.file) {
            resim = req.file.filename;

            fs.unlink("./assets/uploads/" + req.body.resim, (err) => { });
        }

        try {
            await Ekip.update(
                {
                    resim: resim,
                    isim: isim,
                    aciklama: aciklama,
                },
                {
                    where: {
                        id: ekipid,
                    },
                }
            );
            return res.redirect("/admin/ekip");
        } catch (err) {
            console.log(err);
        }
    }
);


//EKİP EKLEME SAYFASI
router.get("/ekip-create", function (req, res) {
    res.render("admin/edit/ekip-create");
});
//EKİP EKLEME İŞLEMİ
router.post(
    "/ekip-create",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const resim = req.file.filename;
        const isim = req.body.isim;
        const aciklama = req.body.aciklama;
        try {
            await Ekip.create({
                resim: resim,
                isim: isim,
                aciklama: aciklama,
            });
            return res.redirect("/admin/ekip");
        } catch (err) {
            console.log(err);
        }
    }
);


//GALERİ SİLME İŞLEMİ
router.post("/galeri", isAuth, async function (req, res) {
    const galeriid = req.body.galeriid;

    try {
        await Galeri.destroy({
            where: {
                id: galeriid,
            },
        });
        return res.redirect("/admin/galeri");
    } catch (err) {
        console.log(err);
    }
});
//GALERİ DÜZENLEME SAYFASI
router.get("/galeri/:galeriid", isAuth, async function (req, res) {
    const galeriid = req.params.galeriid;
    try {
        const galeri = await Galeri.findByPk(galeriid);

        if (galeri) {
            return res.render("admin/edit/galeri-edit", {
                galeri: galeri,
            });
        }
        res.redirect("/admin/galeri");
    } catch (err) {
        console.log(err);
    }
});
//GALERİ DÜZENLEME İŞLEMİ
router.post(
    "/galeri/:galeriid",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const galeriid = req.params.galeriid;
        const anasayfa = req.body.anasayfa == "on" ? 1 : 0;
        let resim = req.body.resim;
        if (req.file) {
            resim = req.file.filename;

            fs.unlink("./assets/uploads/" + req.body.resim, (err) => { });
        }

        try {
            await Galeri.update(
                {
                    resim: resim,
                    anasayfa: anasayfa,
                },
                {
                    where: {
                        id: galeriid,
                    },
                }
            );
            return res.redirect("/admin/galeri");
        } catch (err) {
            console.log(err);
        }
    }
);


//GALERİ EKLEME SAYFASI
router.get("/galeri-create", function (req, res) {
    res.render("admin/edit/galeri-create");
});
//GALERİ EKLEME İŞLEMİ
const multer = require("multer");
const upload = multer({ dest: "./assets/uploads" });
router.post(
    "/galeri-create",
    imageUpload.upload.single("resim"),
    isAuth, async function (req, res) {
        const resim = req.file.filename;
        const anasayfa = req.body.anasayfa == "on" ? 1 : 0;
        try {
            await Galeri.create({
                resim: resim,
                anasayfa: anasayfa,
            });
            return res.redirect("/admin/galeri");
        } catch (err) {
            console.log(err);
        }
    }
);

router.get("/form", isAuth, async function (req, res) {
    try {
        const form = await Form.findAll();
        res.render("admin/form", {
            form: form,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/galeri", isAuth, async function (req, res) {
    try {
        const galeri = await Galeri.findAll();
        res.render("admin/galeri", {
            galeri: galeri,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/menu", isAuth, async function (req, res) {
    try {
        const menu = await Menu.findAll();
        const category = await Category.findAll();
        res.render("admin/menu", {
            menu: menu,
            category:category,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/ekip", isAuth, async function (req, res) {
    try {
        const ekip = await Ekip.findAll();
        res.render("admin/ekip", {
            ekip: ekip,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/category", isAuth, async function (req, res) {
    try {
        const categories = await Category.findAll();
        res.render("admin/category", {
            categories: categories,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/soz", isAuth, async function (req, res) {
    try {
        const soz = await Soz.findAll();
        res.render("admin/soz", {
            soz: soz,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/slider", isAuth, async function (req, res) {
    try {
        const slider = await Slider.findAll();
        res.render("admin/slider", {
            slider: slider,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/hakkimizda", isAuth, async function (req, res) {
    try {
        const hakkimizda = await Hakkimizda.findAll();
        res.render("admin/hakkimizda", {
            hakkimizda: hakkimizda,
        });
    } catch (err) {
        console.log(err);
    }
});
router.get("/", isAuth, async function (req, res) {
    try {
        const form = await Form.findAll();
        const ekip = await Ekip.findAll();
        const menu = await Menu.findAll();
        res.render("admin/index", {
            form: form,
            ekip:ekip,
            menu:menu,
        });
    } catch (err) {
        console.log(err);
    }
});
module.exports = router;