const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Galeri = sequelize.define(
  "galeri",
  {
    resim: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    anasayfa: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Galeri;