const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Ekip = sequelize.define(
  "ekip",
  {
    isim: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    aciklama: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    resim: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Ekip;
