const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Menu = sequelize.define(
  "menu",
  {
    resim: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    isim: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    fiyat: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    aciklama: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Menu;