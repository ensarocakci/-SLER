const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Form = sequelize.define(
  "form",
  {
    mesaj: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    isim: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    mail: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Form;
