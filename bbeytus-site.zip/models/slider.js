const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Slider = sequelize.define(
  "slider",
  {
    resim: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Slider;
