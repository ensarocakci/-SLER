const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Hakkimizda = sequelize.define(
  "hakkimizda",
  {
    resim: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    resim2: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    aciklama: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);
module.exports = Hakkimizda;
