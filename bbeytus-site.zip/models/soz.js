const { DataTypes } = require("sequelize");
const sequelize = require("../data/db");

const Soz = sequelize.define(
  "soz",
  {
    yazi: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    timestamps: false,
  }
);

module.exports = Soz;